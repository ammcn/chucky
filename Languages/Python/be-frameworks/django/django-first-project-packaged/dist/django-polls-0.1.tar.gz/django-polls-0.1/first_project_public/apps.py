from django.apps import AppConfig


class FirstProjectPublicConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'first_project_public'
